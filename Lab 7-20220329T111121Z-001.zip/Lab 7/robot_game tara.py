
from game_lib import *

stateForTask1 = "Go up"
stateForTask2 = "Go up"
stateForTask3 = "Go up"
stateForTask4 = "Find a wall"
stateForTask5 = "Go up"


def makeDecisionForTask0():
    return "UP"

def makeDecisionForTask1():
    global stateForTask1
    if stateForTask1 == "Go up":
        if upIsWall():
            stateForTask1 = "Go right"
            return "NONE"
        else:
            return "UP"
    elif stateForTask1 == "Go right":
        if not upIsWall():
            return "UP"
        else:
            return "RIGHT"

def makeDecisionForTask2():
    global stateForTask2
    if stateForTask2 == "Go up":
        if upIsWall():
            stateForTask2 = "Go right"
            return "NONE"
        else:
            return "UP"
    elif stateForTask2 == "Go right":
        if not upIsWall():
            return "UP"
        elif upIsWall() and not rightIsWall():
            return "RIGHT"
        elif upIsWall() and rightIsWall():
            stateForTask2 = "Go left"
    elif stateForTask2 == "Go left":
        if not upIsWall():
            return "UP"
        elif upIsWall() and not leftIsWall():
            return "LEFT"
        elif upIsWall() and leftIsWall():
            stateForTask2 = "Go right"

def makeDecisionForTask3():
    global stateForTask3
    if stateForTask3 == "Go up":
        if upIsWall():
            stateForTask3 = "Go right"
            return "NONE"
        else:
            return "UP"

    elif stateForTask3 == "Go right":
        if not upIsWall():
            return "UP"
        elif upIsWall() and not rightIsWall():
            return "RIGHT"
        elif upIsWall() and rightIsWall():
            stateForTask3 = "Go left"
    elif stateForTask3 == "Go left":
        if not upIsWall():
            return "UP"
        elif upIsWall() and not leftIsWall():
            return "LEFT"
        elif upIsWall() and leftIsWall():
            stateForTask3 = "Go right"


def makeDecisionForTask4():
    global stateForTask4
    if stateForTask4 == "Find a wall":
        if not upIsWall():
            stateForTask4 = "Go up"
            return "UP"
        if upIsWall() and rightIsWall():
            stateForTask4 = "Go left"
            return "LEFT"
        elif not upIsWall() and not rightIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif upIsWall() and leftIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"

    if stateForTask4 == "Go up":
        if not upIsWall() and leftIsWall() and not rightIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif not upIsWall() and not rightIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif upIsWall() and not rightIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif not upIsWall() and rightIsWall():
            stateForTask4 = "Go up"
            return "UP"
        elif upIsWall() and rightIsWall():
            stateForTask4 = "Go left"
            return "LEFT"
        else:
            return "UP"

    if stateForTask4 == "Go left":
        if upIsWall() and leftIsWall():
            stateForTask4 = "Go down"
            return "DOWN"
        if downIsWall() and leftIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif not upIsWall() and not leftIsWall():
            stateForTask4 = "Find a wall"
            return "UP"
        elif leftIsWall() and not upIsWall():
            stateForTask4 = "Go up"
            return "UP"
        elif not leftIsWall() and upIsWall():
            return "LEFT"

    if stateForTask4 == "Go right":
        if not downIsWall():
            stateForTask4 = "Go down"
            return "DOWN"
        elif rightIsWall() and downIsWall():
            stateForTask4 = "Go up"
            return "UP"
        elif not rightIsWall() and not upIsWall():
            return "RIGHT"
        elif not rightIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif upIsWall() and not rightIsWall() and not downIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif not rightIsWall() and not downIsWall():
            stateForTask4 = "Go down"
            return "DOWN"

    if stateForTask4 == "Go down":
        if downIsWall() and leftIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif downIsWall() and rightIsWall():
            stateForTask4 = "Go up"
            return "UP"
        elif not downIsWall() and not leftIsWall():
            stateForTask4 = "Go left"
            return "LEFT"
        elif not downIsWall() and leftIsWall():
            stateForTask4 = "Go down"
            return "DOWN"
        elif downIsWall() and not leftIsWall():
            stateForTask4 = "Go left"
            return "LEFT"
        elif not rightIsWall():
            stateForTask4 = "Go right"
            return "RIGHT"
        elif not downIsWall():
            return "DOWN"

def makeDecisionForTask5():
    global stateForTask5
    if stateForTask5 == "Find a wall":
        if not upIsWall():
            stateForTask5 = "Go up"
            return "UP"
        if upIsWall() and rightIsWall():
            stateForTask5 = "Go left"
            return "LEFT"
        elif not upIsWall() and not rightIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        elif upIsWall() and leftIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"

    if stateForTask5 == "Go up":
        if not upIsWall() and leftIsWall() and not rightIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        elif not upIsWall() and not rightIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        elif upIsWall() and not rightIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        elif not upIsWall() and rightIsWall():
            stateForTask5 = "Go up"
            return "UP"
        elif upIsWall() and rightIsWall():
            stateForTask5 = "Go left"
            return "LEFT"
        else:
            return "UP"

    if stateForTask5 == "Go left":
        if upIsWall() and leftIsWall():
            stateForTask5 = "Go down"
            return "DOWN"
        if downIsWall() and leftIsWall() and upIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        if downIsWall() and leftIsWall() and not upIsWall():
            stateForTask5 = "Go up"
            return "UP"
        elif not upIsWall() and not leftIsWall():
            stateForTask5 = "Find a wall"
            return "UP"
        elif leftIsWall() and not upIsWall():
            stateForTask5 = "Go up"
            return "UP"
        elif not leftIsWall() and upIsWall():
            return "LEFT"

    if stateForTask5 == "Go right":
        if not downIsWall():
            stateForTask5 = "Go down"
            return "DOWN"
        elif rightIsWall() and downIsWall():
            stateForTask5 = "Go up"
            return "UP"
        elif not rightIsWall() and not upIsWall():
            return "RIGHT"
        elif not rightIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        elif upIsWall() and not rightIsWall() and not downIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        elif not rightIsWall() and not downIsWall():
            stateForTask5 = "Go down"
            return "DOWN"

    if stateForTask5 == "Go down":
        if downIsWall() and leftIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        elif downIsWall() and rightIsWall() and leftIsWall():
            stateForTask5 = "Go up"
            return "UP"
        elif downIsWall() and rightIsWall() and not leftIsWall():
            stateForTask5 = "Go left"
            return "LEFT"
        elif not downIsWall() and not leftIsWall():
            stateForTask5 = "Go left"
            return "LEFT"
        elif not downIsWall() and leftIsWall():
            stateForTask5 = "Go down"
            return "DOWN"
        elif downIsWall() and not leftIsWall():
            stateForTask5 = "Go left"
            return "LEFT"
        elif not rightIsWall():
            stateForTask5 = "Go right"
            return "RIGHT"
        elif not downIsWall():
            return "DOWN"

chooseGameMap("custom", 0)

setDecisionFuncForTask0(makeDecisionForTask0)
setDecisionFuncForTask1(makeDecisionForTask1)
setDecisionFuncForTask2(makeDecisionForTask2)
setDecisionFuncForTask3(makeDecisionForTask3)
setDecisionFuncForTask4(makeDecisionForTask4)
setDecisionFuncForTask5(makeDecisionForTask5)

# Start the game
startGame()
